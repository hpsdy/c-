// Copyright 2013 Baidu.com  All Rights Reserved.
// Author: wangguangyuan@baidu.com (Guangyuan Wang)
#ifndef  UTIL_UTIL_H_
#define  UTIL_UTIL_H_

#include "unise/util.h"
#include "unise/base.h"

#endif  // UTIL_UTIL_H_

/* vim: set expandtab ts=2 sw=2 sts=2 tw=80: */

#ifndef UTIL_HASH_TABLES_H
#define UTIL_HASH_TABLES_H

#include "base/containers/hash_tables.h"

// 这里曾经unise也使用了chrome的hash_tables.h，由于baidu-rpc也用了
// 且unise的依赖baidu-rpc，所以，这里理应删除定义
// 为了兼容，做一个头文件include

#endif  // UTIL_HASH_TABLES_H
